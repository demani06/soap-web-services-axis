package com.deepak.ws;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );

       /* try {
            *//*HelloWorldServiceImplServiceStub stub = new HelloWorldServiceImplServiceStub();
            HelloWorldDocument document = HelloWorldDocument.Factory.newInstance();
            HelloWorld helloWorld = HelloWorld.Factory.newInstance();
            helloWorld.setArg0("Vasudevan");
            document.setHelloWorld(helloWorld);
            //Arg1Document arg1Document = Arg1Document.Factory.newInstance();
            HelloWorldResponseDocument response = stub.helloWorld(document);
            System.out.println("response="+response);*//*
        } catch (AxisFault axisFault) {
            axisFault.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }*/
    }
}
